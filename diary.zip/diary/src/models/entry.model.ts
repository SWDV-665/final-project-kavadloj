export interface Entry {
    title: string
    content: string
    date: Date
    createDate: number
}