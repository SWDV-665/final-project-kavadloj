import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { DiaryServiceProvider } from '../../providers/diary-service/diary-service';
import { Entry } from '../../models/entry.model';
import { SocialSharing } from '@ionic-native/social-sharing';

@IonicPage()
@Component({
  selector: 'page-view-entry',
  templateUrl: 'view-entry.html',
})
export class ViewEntryPage {
  entry: Entry;

  constructor(public navCtrl: NavController, public navParams: NavParams, private diaryService: DiaryServiceProvider, public socialSharing: SocialSharing) {
    this.entry = this.navParams.get('entry');
  }

  deleteEntry(createDate: number) {
    this.diaryService.deleteEntry(createDate);
    this.navCtrl.pop();
  }

  shareEntry(createDate: number) {
    let message = "Entry title: " + this.entry.title + 
                  " Entry content: " + this.entry.content;
    let subject = "Shared via Diary app";

    this.socialSharing.share(message, subject).then(() => {
      console.log("Shared successfully!");
    }).catch((error) => {
      console.error("Error while sharing", error);
    });
  }
}
