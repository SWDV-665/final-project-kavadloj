import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { NewEntryPage } from '../new-entry/new-entry';
import { DiaryServiceProvider } from '../../providers/diary-service/diary-service';
import { Entry } from '../../models/entry.model';
import { ViewEntryPage } from '../view-entry/view-entry';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  entries : Promise<Entry[]>;
  private entry: Entry;

  constructor(public navCtrl: NavController, private diaryService: DiaryServiceProvider) {

  }

  ionViewWillEnter() {
    this.entries = this.getAllEntries();
  }

  createEntry(){
    this.navCtrl.push(NewEntryPage);
  }

  getEntry(createDate: number) {
    this.diaryService.getEntry(createDate).then((e) => {
      this.entry = e;
      this.navCtrl.push(ViewEntryPage, { entry: this.entry })
    })
  }

  getAllEntries() {
    return this.diaryService.getAllEntries();
  }
}
