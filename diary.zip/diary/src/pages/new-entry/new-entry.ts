import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { DiaryServiceProvider } from '../../providers/diary-service/diary-service'
import { Entry } from '../../models/entry.model';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@IonicPage()
@Component({
  selector: 'page-new-entry',
  templateUrl: 'new-entry.html',
})
export class NewEntryPage {
  formGroup: FormGroup;
  entry: Entry;
  date: Date = new Date();
  title: string = '';
  content: string = '';

  constructor(public navCtrl: NavController, private diaryService: DiaryServiceProvider) {
    this.formGroup = new FormGroup( {
      title: new FormControl(),
      content: new FormControl(),
      date: new FormControl(),
    })
  }

  saveEntry(entry: Entry) {
    this.diaryService.saveEntry(entry);
    this.navCtrl.pop();
  }
}
