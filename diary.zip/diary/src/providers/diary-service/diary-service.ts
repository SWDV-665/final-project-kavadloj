import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { Entry } from '../../models/entry.model';

@Injectable()
export class DiaryServiceProvider {

  private entries: Entry[] = [];
  private entry: Entry;

  constructor(public storage: Storage) {  }

  saveEntry(entry: Entry) {
    entry.createDate = Date.now();
    this.entries.push(entry);
    this.storage.set('entries', this.entries);
  }

  getAllEntries() {
    return this.storage.get('entries').then(
      (entries) => {
        this.entries = entries == null ? [] : entries;
        return [...this.entries];
      }
    )
  }

  getEntry(createDate: number) {
    return this.storage.get('entries').then((entries) => {
      this.entry = [...entries].find(r => r.createDate === createDate);
      return this.entry;
    });
  }

  deleteEntry(createDate: number){
    this.entries = this.entries.filter((entry) => {
      return entry.createDate !== createDate
    });
    this.storage.set('entries', this.entries);
  }
}
